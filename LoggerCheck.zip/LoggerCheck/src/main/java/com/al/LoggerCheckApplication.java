package com.al;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LoggerCheckApplication {
	static final Logger log = LoggerFactory.getLogger(LoggerCheckApplication.class);
	 public static void main(String[] args) {
		  log.info("you found your info");
		  log.warn("warn executed^^^^^^^^");
		  log.error("Erorrrrrrrrrrrrrrrr!!!!!!!!!");
		  log.trace(" you have been tracing your project erorr");
		  log.debug("nothing to debuggggg::::::::::::::::");
		SpringApplication.run(LoggerCheckApplication.class, args);
	}

}

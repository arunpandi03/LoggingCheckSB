package com.al;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggerCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
